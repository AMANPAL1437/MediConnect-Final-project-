package com.mediconnect.db;
import java.sql.Connection; import java.sql.DriverManager; import java.sql.SQLException;
public final class Database {
    private static final String URL=System.getenv().containsKey("MEDICONNECT_DB_URL")?System.getenv("MEDICONNECT_DB_URL"):"jdbc:mysql://localhost:3306/mediconnect?useSSL=false&serverTimezone=UTC";
    private static final String USER=System.getenv().containsKey("MEDICONNECT_DB_USER")?System.getenv("MEDICONNECT_DB_USER"):"root";
    private static final String PASSWORD=System.getenv().containsKey("MEDICONNECT_DB_PASSWORD")?System.getenv("MEDICONNECT_DB_PASSWORD"):"";
    private Database(){}
    public static Connection getConnection() throws SQLException {return DriverManager.getConnection(URL,USER,PASSWORD);}
}
