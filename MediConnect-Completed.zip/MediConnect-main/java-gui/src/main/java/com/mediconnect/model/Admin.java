package com.mediconnect.model;
public class Admin extends Person {
    public Admin(int id,String name,String email,String phone){super(id,name,email,phone);}
    @Override public String getRole(){return "ADMIN";}
}
