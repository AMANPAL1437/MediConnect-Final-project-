package com.mediconnect.exception;
public class InvalidAppointmentException extends Exception {
    public InvalidAppointmentException(String message){super(message);}
}
