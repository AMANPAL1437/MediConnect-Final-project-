# MediConnect Java GUI module (Java 8)

This module is added alongside the original React/Vite website to meet the GUVI HCL **Java GUI Based Projects** rubric. It demonstrates:
- OOP: abstract base class, inheritance, runtime polymorphism, encapsulation, interface and custom exceptions.
- Collections & Generics: generic `Repository<T>`, `InMemoryRepository<T>`, `List`, `Map`, `Collections`.
- Multithreading & Synchronization: `ExecutorService`, `Callable`, `Future`, `AtomicInteger`, synchronized methods and synchronized collection.
- Database operation classes: DAO classes (`PatientDAO`, `DoctorDAO`, `AppointmentDAO`).
- JDBC: `DriverManager`, `Connection`, `PreparedStatement`, `Statement`, `ResultSet`, try-with-resources.
- Swing GUI: dashboard and patient/doctor/appointment tables.

## Requirements
- JDK 8 or later
- Maven 3.6+
- MySQL Server / MySQL Workbench

## 1. Create the database
Open MySQL Workbench and run `database/schema.sql`.

## 2. Configure database credentials
Defaults are `root` with an empty password. For a different setup, set environment variables before launching:
- `MEDICONNECT_DB_URL` (optional; default `jdbc:mysql://localhost:3306/mediconnect?useSSL=false&serverTimezone=UTC`)
- `MEDICONNECT_DB_USER`
- `MEDICONNECT_DB_PASSWORD`

PowerShell example:
```powershell
$env:MEDICONNECT_DB_USER="root"
$env:MEDICONNECT_DB_PASSWORD="your_mysql_password"
```

## 3. Run in VS Code terminal
Open the `java-gui` folder (or open the whole MediConnect folder), then run:
```powershell
mvn clean compile
mvn exec:java
```
Maven downloads the MySQL JDBC driver automatically. If Maven is not installed, install Apache Maven and ensure `mvn -version` works.

## Notes
- The original web app remains in the repository root. Its commands remain `npm.cmd install` and `npm.cmd run dev`.
- The Java Swing application is a separate desktop GUI module because the submitted repository was originally a React/TypeScript web application, not a Java project.
- Sample in-memory records are for demonstration only. MySQL operations require the schema and credentials above. Use unique email addresses when inserting sample users more than once.
- This is an educational demo, not a production medical-record system. Do not use real patient data.
