package com.mediconnect.dao;
import com.mediconnect.db.Database; import com.mediconnect.model.Patient; import com.mediconnect.exception.DatabaseOperationException;
import java.sql.*; import java.util.*;
public class PatientDAO {
    public void insert(Patient p){
        String sql="INSERT INTO patients(name,email,phone,blood_group) VALUES(?,?,?,?)";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,p.getName());ps.setString(2,p.getEmail());ps.setString(3,p.getPhone());ps.setString(4,p.getBloodGroup());ps.executeUpdate();
        }catch(SQLException e){throw new DatabaseOperationException("Could not save patient. Check database setup and duplicate email.",e);}
    }
    public List<Patient> findAll(){
        List<Patient> list=new ArrayList<Patient>();String sql="SELECT id,name,email,phone,blood_group FROM patients ORDER BY id";
        try(Connection c=Database.getConnection();Statement st=c.createStatement();ResultSet rs=st.executeQuery(sql)){
            while(rs.next())list.add(new Patient(rs.getInt("id"),rs.getString("name"),rs.getString("email"),rs.getString("phone"),rs.getString("blood_group")));
            return list;
        }catch(SQLException e){throw new DatabaseOperationException("Could not load patients. Check database connection.",e);}
    }
}
