package com.mediconnect.repository;
import com.mediconnect.model.Person;
import java.util.List;
public interface Repository<T extends Person> { void save(T item); List<T> findAll(); }
