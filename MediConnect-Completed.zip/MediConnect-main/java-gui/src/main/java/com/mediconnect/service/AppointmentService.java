package com.mediconnect.service;
import com.mediconnect.model.Appointment;
import com.mediconnect.exception.InvalidAppointmentException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public class AppointmentService {
    private final List<Appointment> appointments = Collections.synchronizedList(new ArrayList<Appointment>());
    private final AtomicInteger completedBackgroundJobs = new AtomicInteger(0);
    public synchronized void book(Appointment appointment) throws InvalidAppointmentException {
        if(appointment == null) throw new InvalidAppointmentException("Appointment is required");
        if(appointment.getDate()==null || appointment.getDate().isBefore(java.time.LocalDate.now()))
            throw new InvalidAppointmentException("Appointment date cannot be in the past");
        appointments.add(appointment);
    }
    public List<Appointment> getAll(){synchronized(appointments){return new ArrayList<Appointment>(appointments);}}
    public int runBackgroundTasks(int taskCount) throws InterruptedException {
        ExecutorService pool=Executors.newFixedThreadPool(3);
        List<Future<Integer>> results=new ArrayList<Future<Integer>>();
        for(int i=1;i<=taskCount;i++){
            final int task=i;
            results.add(pool.submit(new Callable<Integer>() {
                public Integer call(){try{Thread.sleep(250);}catch(InterruptedException e){Thread.currentThread().interrupt();}
                    return completedBackgroundJobs.incrementAndGet();}
            }));
        }
        int done=0; try { for(Future<Integer> f:results){f.get();done++;} }
        catch(ExecutionException e){throw new IllegalStateException("Background task failed",e);}
        finally {pool.shutdown();}
        return done;
    }
}
