package com.mediconnect.model;
public class Patient extends Person {
    private String bloodGroup;
    public Patient(int id,String name,String email,String phone,String bloodGroup){super(id,name,email,phone);this.bloodGroup=bloodGroup;}
    public String getBloodGroup(){return bloodGroup;}
    @Override public String getRole(){return "PATIENT";}
    @Override public String getSummary(){return super.getSummary()+" | Blood group: "+bloodGroup;}
}
