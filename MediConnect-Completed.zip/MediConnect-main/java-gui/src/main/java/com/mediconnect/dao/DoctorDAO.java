package com.mediconnect.dao;
import com.mediconnect.db.Database; import com.mediconnect.model.Doctor; import com.mediconnect.exception.DatabaseOperationException;
import java.sql.*; import java.util.*;
public class DoctorDAO {
    public void insert(Doctor d){
        String sql="INSERT INTO doctors(name,email,phone,specialization,consultation_fee) VALUES(?,?,?,?,?)";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,d.getName());ps.setString(2,d.getEmail());ps.setString(3,d.getPhone());ps.setString(4,d.getSpecialization());ps.setDouble(5,d.getConsultationFee());ps.executeUpdate();
        }catch(SQLException e){throw new DatabaseOperationException("Could not save doctor. Check database setup and duplicate email.",e);}
    }
    public List<Doctor> findAll(){
        List<Doctor> list=new ArrayList<Doctor>();String sql="SELECT id,name,email,phone,specialization,consultation_fee FROM doctors ORDER BY id";
        try(Connection c=Database.getConnection();Statement st=c.createStatement();ResultSet rs=st.executeQuery(sql)){
            while(rs.next())list.add(new Doctor(rs.getInt("id"),rs.getString("name"),rs.getString("email"),rs.getString("phone"),rs.getString("specialization"),rs.getDouble("consultation_fee")));
            return list;
        }catch(SQLException e){throw new DatabaseOperationException("Could not load doctors. Check database connection.",e);}
    }
}
