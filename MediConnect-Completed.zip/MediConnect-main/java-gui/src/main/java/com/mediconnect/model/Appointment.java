package com.mediconnect.model;
import java.time.LocalDate;
public class Appointment {
    private int id, patientId, doctorId; private String reason, status; private LocalDate date;
    public Appointment(int id,int patientId,int doctorId,LocalDate date,String reason,String status){
        this.id=id;this.patientId=patientId;this.doctorId=doctorId;this.date=date;this.reason=reason;this.status=status;
    }
    public int getId(){return id;} public int getPatientId(){return patientId;} public int getDoctorId(){return doctorId;}
    public LocalDate getDate(){return date;} public String getReason(){return reason;} public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}
    @Override public String toString(){return "Appointment #"+id+" | Patient "+patientId+" | Doctor "+doctorId+" | "+date+" | "+status+" | "+reason;}
}
