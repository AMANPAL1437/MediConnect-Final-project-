package com.mediconnect.repository;
import com.mediconnect.model.Person;
import java.util.*;
public class InMemoryRepository<T extends Person> implements Repository<T> {
    private final Map<Integer,T> items = new LinkedHashMap<Integer,T>();
    public synchronized void save(T item) {
        if(item == null) throw new IllegalArgumentException("Item cannot be null");
        items.put(item.getId(), item);
    }
    public synchronized List<T> findAll(){return new ArrayList<T>(items.values());}
    public synchronized int size(){return items.size();}
}
