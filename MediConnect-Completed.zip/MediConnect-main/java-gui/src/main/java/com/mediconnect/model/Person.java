package com.mediconnect.model;
public abstract class Person {
    private int id; private String name; private String email; private String phone;
    public Person(int id, String name, String email, String phone) {
        this.id=id; this.name=name; this.email=email; this.phone=phone;
    }
    public int getId(){return id;} public void setId(int id){this.id=id;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public String getEmail(){return email;} public String getPhone(){return phone;}
    public abstract String getRole();
    public String getSummary(){return getRole()+": "+name+" ("+email+")";}
}
