package com.mediconnect.model;
public interface Payable { double calculateAmount(); }
