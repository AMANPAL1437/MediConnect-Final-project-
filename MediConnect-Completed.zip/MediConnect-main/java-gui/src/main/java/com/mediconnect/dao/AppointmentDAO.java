package com.mediconnect.dao;
import com.mediconnect.db.Database; import com.mediconnect.model.Appointment; import com.mediconnect.exception.DatabaseOperationException;
import java.sql.*; import java.util.*; import java.time.LocalDate;
public class AppointmentDAO {
    public void insert(Appointment a){
        String sql="INSERT INTO appointments(patient_id,doctor_id,appointment_date,reason,status) VALUES(?,?,?,?,?)";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,a.getPatientId());ps.setInt(2,a.getDoctorId());ps.setDate(3,java.sql.Date.valueOf(a.getDate()));ps.setString(4,a.getReason());ps.setString(5,a.getStatus());ps.executeUpdate();
        }catch(SQLException e){throw new DatabaseOperationException("Could not save appointment. Verify patient/doctor IDs.",e);}
    }
    public List<Appointment> findAll(){
        List<Appointment> list=new ArrayList<Appointment>();String sql="SELECT id,patient_id,doctor_id,appointment_date,reason,status FROM appointments ORDER BY appointment_date";
        try(Connection c=Database.getConnection();Statement st=c.createStatement();ResultSet rs=st.executeQuery(sql)){
            while(rs.next())list.add(new Appointment(rs.getInt("id"),rs.getInt("patient_id"),rs.getInt("doctor_id"),rs.getDate("appointment_date").toLocalDate(),rs.getString("reason"),rs.getString("status")));
            return list;
        }catch(SQLException e){throw new DatabaseOperationException("Could not load appointments. Check database connection.",e);}
    }
}
