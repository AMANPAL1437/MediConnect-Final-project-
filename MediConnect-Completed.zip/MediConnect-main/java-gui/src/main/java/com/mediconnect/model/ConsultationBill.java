package com.mediconnect.model;
public class ConsultationBill implements Payable {
    private Doctor doctor; private double taxRate;
    public ConsultationBill(Doctor doctor,double taxRate){this.doctor=doctor;this.taxRate=taxRate;}
    @Override public double calculateAmount(){return doctor.getConsultationFee()*(1.0+taxRate);}
}
