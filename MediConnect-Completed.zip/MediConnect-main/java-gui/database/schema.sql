CREATE DATABASE IF NOT EXISTS mediconnect;
USE mediconnect;
CREATE TABLE IF NOT EXISTS patients (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 phone VARCHAR(20),
 blood_group VARCHAR(5)
);
CREATE TABLE IF NOT EXISTS doctors (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 phone VARCHAR(20),
 specialization VARCHAR(100) NOT NULL,
 consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS appointments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 patient_id INT NOT NULL,
 doctor_id INT NOT NULL,
 appointment_date DATE NOT NULL,
 reason VARCHAR(500),
 status VARCHAR(30) NOT NULL DEFAULT 'Pending',
 CONSTRAINT fk_appointment_patient FOREIGN KEY(patient_id) REFERENCES patients(id),
 CONSTRAINT fk_appointment_doctor FOREIGN KEY(doctor_id) REFERENCES doctors(id)
);
