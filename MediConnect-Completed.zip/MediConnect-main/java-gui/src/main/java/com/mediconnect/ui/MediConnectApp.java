package com.mediconnect.ui;
import com.mediconnect.model.*; import com.mediconnect.repository.*; import com.mediconnect.service.AppointmentService;
import com.mediconnect.dao.*; import com.mediconnect.exception.*;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.time.LocalDate; import java.util.List;
public class MediConnectApp extends JFrame {
    private final InMemoryRepository<Patient> patients=new InMemoryRepository<Patient>();
    private final InMemoryRepository<Doctor> doctors=new InMemoryRepository<Doctor>();
    private final AppointmentService appointmentService=new AppointmentService();
    private final PatientDAO patientDAO=new PatientDAO(); private final DoctorDAO doctorDAO=new DoctorDAO(); private final AppointmentDAO appointmentDAO=new AppointmentDAO();
    private final DefaultTableModel patientModel=model("ID","Name","Email","Phone","Blood Group");
    private final DefaultTableModel doctorModel=model("ID","Name","Specialization","Email","Fee");
    private final DefaultTableModel appointmentModel=model("ID","Patient ID","Doctor ID","Date","Reason","Status");
    private final JTextArea log=new JTextArea();
    public MediConnectApp(){
        super("MediConnect | Hospital Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);setSize(1050,680);setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10,10));
        JLabel header=new JLabel("  MediConnect - Java GUI Hospital Management",SwingConstants.LEFT);
        header.setOpaque(true);header.setBackground(new Color(22,74,135));header.setForeground(Color.WHITE);header.setFont(new Font("SansSerif",Font.BOLD,22));header.setPreferredSize(new Dimension(100,58));add(header,BorderLayout.NORTH);
        JTabbedPane tabs=new JTabbedPane();tabs.addTab("Dashboard",dashboard());tabs.addTab("Patients",tablePanel(patientModel));tabs.addTab("Doctors",tablePanel(doctorModel));tabs.addTab("Appointments",tablePanel(appointmentModel));add(tabs,BorderLayout.CENTER);
        seedDemoData();refreshMemoryTables();
    }
    private JPanel dashboard(){
        JPanel p=new JPanel(new BorderLayout(12,12));p.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));
        JLabel intro=new JLabel("<html><h1>Welcome to MediConnect</h1><p>Patient, doctor and appointment management using Java Swing, OOP, Collections, Threads and JDBC.</p></html>");
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addPatient=new JButton("Add sample patient");addPatient.addActionListener(e->{Patient x=new Patient(0,"New Patient","new.patient@example.com","9999999999","O+");try{patientDAO.insert(x);loadPatientsFromDb();message("Patient saved in MySQL.");}catch(RuntimeException ex){message(ex.getMessage());}});
        JButton addDoctor=new JButton("Add sample doctor");addDoctor.addActionListener(e->{Doctor x=new Doctor(0,"Dr. Demo","demo.doctor@example.com","8888888888","General Medicine",500);try{doctorDAO.insert(x);loadDoctorsFromDb();message("Doctor saved in MySQL.");}catch(RuntimeException ex){message(ex.getMessage());}});
        JButton loadDb=new JButton("Load all data from MySQL");loadDb.addActionListener(e->{loadAllFromDb();});
        JButton threads=new JButton("Run 5 background tasks");threads.addActionListener(e->{threads.setEnabled(false);new SwingWorker<Integer,Void>(){protected Integer doInBackground()throws Exception{return appointmentService.runBackgroundTasks(5);}protected void done(){try{message("Multithreading demo: "+get()+" tasks completed safely.");}catch(Exception ex){message("Thread task failed: "+ex.getMessage());}threads.setEnabled(true);}}.execute();});
        JButton book=new JButton("Create demo appointment");book.addActionListener(e->{try{appointmentService.book(new Appointment(100,1,1,LocalDate.now().plusDays(1),"General check-up","Pending"));appointmentModel.addRow(new Object[]{100,1,1,LocalDate.now().plusDays(1),"General check-up","Pending"});message("Appointment validated and added to synchronized in-memory collection.");}catch(InvalidAppointmentException ex){message(ex.getMessage());}});
        actions.add(addPatient);actions.add(addDoctor);actions.add(loadDb);actions.add(threads);actions.add(book);
        log.setEditable(false);log.setRows(10);log.setText("Application ready. Use the buttons to demonstrate CRUD/JDBC, OOP, Collections and multithreading.\n");
        p.add(intro,BorderLayout.NORTH);p.add(actions,BorderLayout.CENTER);p.add(new JScrollPane(log),BorderLayout.SOUTH);return p;
    }
    private JPanel tablePanel(DefaultTableModel model){JPanel p=new JPanel(new BorderLayout());JTable table=new JTable(model);table.setRowHeight(26);p.add(new JScrollPane(table),BorderLayout.CENTER);return p;}
    private DefaultTableModel model(String... cols){return new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};}
    private void seedDemoData(){
        patients.save(new Patient(1,"Aman Pal","aman@example.com","9876543210","O+"));
        patients.save(new Patient(2,"Riya Sharma","riya@example.com","9876543211","A+"));
        doctors.save(new Doctor(1,"Dr. Rahul Sharma","rahul@example.com","9876543212","Cardiology",1200));
        doctors.save(new Doctor(2,"Dr. Priya Patel","priya@example.com","9876543213","General Medicine",800));
        Person p=new Patient(3,"Demo Patient","demo@example.com","9000000000","B+");
        log.append("Polymorphism demo -> "+p.getSummary()+"\n");
        ConsultationBill bill=new ConsultationBill(new Doctor(3,"Dr. Bill","bill@example.com","9000000001","Dentistry",600),0.18);
        log.append("Interface/abstraction demo -> payable amount Rs."+String.format("%.2f",bill.calculateAmount())+"\n");
    }
    private void refreshMemoryTables(){
        patientModel.setRowCount(0);for(Patient p:patients.findAll())patientModel.addRow(new Object[]{p.getId(),p.getName(),p.getEmail(),p.getPhone(),p.getBloodGroup()});
        doctorModel.setRowCount(0);for(Doctor d:doctors.findAll())doctorModel.addRow(new Object[]{d.getId(),d.getName(),d.getSpecialization(),d.getEmail(),d.getConsultationFee()});
    }
    private void loadPatientsFromDb(){List<Patient> list=patientDAO.findAll();patientModel.setRowCount(0);for(Patient p:list)patientModel.addRow(new Object[]{p.getId(),p.getName(),p.getEmail(),p.getPhone(),p.getBloodGroup()});}
    private void loadDoctorsFromDb(){List<Doctor> list=doctorDAO.findAll();doctorModel.setRowCount(0);for(Doctor d:list)doctorModel.addRow(new Object[]{d.getId(),d.getName(),d.getSpecialization(),d.getEmail(),d.getConsultationFee()});}
    private void loadAllFromDb(){try{loadPatientsFromDb();loadDoctorsFromDb();appointmentModel.setRowCount(0);for(Appointment a:appointmentDAO.findAll())appointmentModel.addRow(new Object[]{a.getId(),a.getPatientId(),a.getDoctorId(),a.getDate(),a.getReason(),a.getStatus()});message("Database records loaded successfully.");}catch(RuntimeException ex){message(ex.getMessage());}}
    private void message(String s){log.append(s+"\n");}
    public static void main(String[] args){SwingUtilities.invokeLater(new Runnable(){public void run(){new MediConnectApp().setVisible(true);}});}
}
