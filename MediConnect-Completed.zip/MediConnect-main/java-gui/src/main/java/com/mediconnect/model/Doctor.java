package com.mediconnect.model;
public class Doctor extends Person {
    private String specialization; private double consultationFee;
    public Doctor(int id,String name,String email,String phone,String specialization,double fee){super(id,name,email,phone);this.specialization=specialization;this.consultationFee=fee;}
    public String getSpecialization(){return specialization;} public double getConsultationFee(){return consultationFee;}
    @Override public String getRole(){return "DOCTOR";}
    @Override public String getSummary(){return super.getSummary()+" | "+specialization+" | Fee: Rs."+consultationFee;}
}
